from pathlib import Path
from dikwp_oncoevidence.analyzer import analyze, load_corpus
from dikwp_oncoevidence.static_audit import audit

ROOT = Path(__file__).resolve().parents[1]

def test_load_corpus():
    corpus = load_corpus(str(ROOT / "examples" / "sample_oncology_research_corpus.json"))
    assert len(corpus.records) == 8
    assert corpus.records[0].cancer_type == "NSCLC"

def test_analyze_outputs(tmp_path):
    report = analyze(str(ROOT / "examples" / "sample_oncology_research_corpus.json"), str(tmp_path))
    assert report["record_count"] == 8
    assert (tmp_path / "evidence_matrix.csv").exists()
    assert (tmp_path / "trial_review_queue.csv").exists()
    assert report["decision_summary"].get("evidence_anchor", 0) >= 1

def test_static_audit():
    res = audit(str(ROOT / "src"))
    assert res["pass"] is True
