# Code of Conduct

Use this project for responsible research evidence organization. Do not use it to make patient-specific clinical decisions.
