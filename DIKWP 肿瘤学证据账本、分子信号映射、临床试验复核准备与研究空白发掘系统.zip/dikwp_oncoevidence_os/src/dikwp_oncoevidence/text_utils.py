import re
from typing import List

def norm(text: str) -> str:
    return re.sub(r"\s+", " ", (text or "").strip())

def contains_any(text: str, terms: List[str]) -> bool:
    low = (text or "").lower()
    return any(t.lower() in low for t in terms)

def slug(text: str) -> str:
    s = re.sub(r"[^a-zA-Z0-9]+", "-", text.lower()).strip("-")
    return s or "item"
