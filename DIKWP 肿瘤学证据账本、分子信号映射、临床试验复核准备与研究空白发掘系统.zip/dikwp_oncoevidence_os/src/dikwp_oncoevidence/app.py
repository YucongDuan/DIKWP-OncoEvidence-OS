# Optional Streamlit UI; imported only when explicitly run by user.
try:
    import streamlit as st
except Exception:  # pragma: no cover
    st = None

from .analyzer import analyze


def main():
    if st is None:
        raise SystemExit("Install streamlit to use the UI: pip install -e .[app]")
    st.title("DIKWP OncoEvidence OS")
    st.write("Research-only oncology evidence ledger and SemanticClosure workbench.")
    uploaded = st.file_uploader("Upload oncology corpus JSON", type=["json"])
    if uploaded:
        import tempfile, json
        with tempfile.NamedTemporaryFile(delete=False, suffix=".json") as f:
            f.write(uploaded.read())
            path = f.name
        report = analyze(path, "outputs/streamlit")
        st.json(report)

if __name__ == "__main__":
    main()
