from pathlib import Path
import ast
import json

BAD_MODULES = {"requests", "urllib", "socket", "subprocess", "selenium", "playwright", "httpx"}
BAD_CALLS = {"eval", "exec", "compile"}
BAD_ATTRS = {("os", "system"), ("os", "popen")}
BAD_NAME_TERMS = {"diagnose_patient", "prescribe", "autotreat", "auto_prescribe"}


def _scan_file(path: Path):
    findings = []
    try:
        tree = ast.parse(path.read_text(encoding="utf-8"))
    except SyntaxError as e:
        return [{"file": str(path), "term": "syntax_error", "line": e.lineno}]
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                root = alias.name.split(".")[0]
                if root in BAD_MODULES:
                    findings.append({"file": str(path), "term": f"import:{alias.name}", "line": node.lineno})
        elif isinstance(node, ast.ImportFrom):
            root = (node.module or "").split(".")[0]
            if root in BAD_MODULES:
                findings.append({"file": str(path), "term": f"from:{node.module}", "line": node.lineno})
        elif isinstance(node, ast.Call):
            if isinstance(node.func, ast.Name) and node.func.id in BAD_CALLS:
                findings.append({"file": str(path), "term": f"call:{node.func.id}", "line": node.lineno})
            if isinstance(node.func, ast.Attribute) and isinstance(node.func.value, ast.Name):
                pair = (node.func.value.id, node.func.attr)
                if pair in BAD_ATTRS:
                    findings.append({"file": str(path), "term": f"call:{pair[0]}.{pair[1]}", "line": node.lineno})
        elif isinstance(node, (ast.FunctionDef, ast.ClassDef, ast.AsyncFunctionDef)):
            if node.name in BAD_NAME_TERMS:
                findings.append({"file": str(path), "term": f"name:{node.name}", "line": node.lineno})
    return findings


def audit(path: str) -> dict:
    root = Path(path)
    findings = []
    for p in root.rglob("*.py"):
        findings.extend(_scan_file(p))
    return {
        "pass": len(findings) == 0,
        "finding_count": len(findings),
        "findings": findings,
        "policy": "No network imports, shell helpers, dynamic code execution, hidden telemetry, host mutation, or clinical decision automation in the offline core.",
    }

if __name__ == "__main__":
    import sys
    print(json.dumps(audit(sys.argv[1] if len(sys.argv)>1 else "src"), indent=2))
