import csv
import json
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Dict, List, Tuple

from .models import Corpus, EvidenceRecord, TrialRecord, VariantSignal
from .text_utils import contains_any, norm

STUDY_BASE = {
    "guideline": 0.86,
    "systematic_review": 0.84,
    "meta_analysis": 0.82,
    "randomized_trial": 0.78,
    "phase_iii_trial": 0.76,
    "prospective_cohort": 0.68,
    "retrospective_cohort": 0.58,
    "real_world_evidence": 0.55,
    "case_series": 0.38,
    "case_report": 0.25,
    "preclinical": 0.30,
    "mechanism_study": 0.34,
    "expert_opinion": 0.28,
}

CANCER_TOPICS = {
    "NSCLC": ["nsclc", "lung", "肺", "egfr", "alk", "ros1"],
    "Breast": ["breast", "乳腺", "her2", "er-positive", "brca"],
    "Colorectal": ["colorectal", "colon", "rectal", "结直肠", "msi", "kras"],
    "Gastric": ["gastric", "stomach", "胃癌"],
    "Liver/HCC": ["hcc", "hepatocellular", "liver", "肝癌"],
    "Pancreatic": ["pancreatic", "胰腺"],
    "Hematologic": ["leukemia", "lymphoma", "myeloma", "白血病", "淋巴瘤"],
    "Rare/Pediatric": ["pediatric", "childhood", "rare", "sarcoma", "儿童"],
}

DOMAIN_TERMS = {
    "Genomics": ["variant", "mutation", "biomarker", "genomic", "sequencing", "基因", "突变"],
    "Immunotherapy": ["immunotherapy", "checkpoint", "pd-1", "pd-l1", "ctla", "免疫"],
    "Targeted Therapy": ["targeted", "inhibitor", "egfr", "alk", "her2", "braf", "靶向"],
    "Screening/Early Detection": ["screen", "early detection", "筛查", "早筛"],
    "Radiotherapy/Surgery": ["radiation", "radiotherapy", "surgery", "手术", "放疗"],
    "Toxicity/Supportive Care": ["toxicity", "adverse", "quality of life", "supportive", "不良反应"],
    "Real-World Evidence": ["real-world", "registry", "ehr", "claims", "真实世界"],
}

UNCERTAINTY_TERMS = ["may", "might", "potential", "associated", "trend", "exploratory", "hypothesis", "suggests", "可能", "趋势", "探索"]
OVERCLAIM_TERMS = ["guarantee", "100%", "cure", "always", "only correct", "必然", "保证", "治愈所有"]


def load_corpus(path: str) -> Corpus:
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    records = [EvidenceRecord(**r) for r in data.get("records", [])]
    trials = [TrialRecord(**t) for t in data.get("trials", [])]
    variants = [VariantSignal(**v) for v in data.get("variants", [])]
    return Corpus(
        corpus_id=data.get("corpus_id", "corpus-001"),
        title=data.get("title", "Oncology evidence corpus"),
        purpose=data.get("purpose", "Research evidence organization"),
        constraints=data.get("constraints", []),
        records=records,
        trials=trials,
        variants=variants,
        metadata=data.get("metadata", {}),
    )


def classify_topic(record: EvidenceRecord) -> Tuple[str, str]:
    text = " ".join([record.title, record.cancer_type, record.biomarker, record.variant, record.intervention, record.claim]).lower()
    topic = record.cancer_type or "Other"
    for k, terms in CANCER_TOPICS.items():
        if any(t.lower() in text for t in terms):
            topic = k
            break
    domain = record.domain or "General Oncology"
    for k, terms in DOMAIN_TERMS.items():
        if any(t.lower() in text for t in terms):
            domain = k
            break
    return topic, domain


def evidence_score(record: EvidenceRecord) -> Tuple[float, List[str]]:
    reasons = []
    score = STUDY_BASE.get(record.study_type, 0.35)
    reasons.append(f"study_type_base={score:.2f}")
    if record.sample_size is None:
        score -= 0.10
        reasons.append("missing_sample_size=-0.10")
    elif record.sample_size >= 1000:
        score += 0.07
        reasons.append("large_sample_size=+0.07")
    elif record.sample_size >= 200:
        score += 0.04
        reasons.append("moderate_sample_size=+0.04")
    elif record.sample_size < 30:
        score -= 0.07
        reasons.append("very_small_sample_size=-0.07")
    if record.source_id:
        score += 0.04
        reasons.append("source_identifier=+0.04")
    else:
        score -= 0.06
        reasons.append("missing_source_identifier=-0.06")
    if record.endpoint_types:
        score += min(0.05, 0.015 * len(record.endpoint_types))
        reasons.append("endpoint_declared=+")
    else:
        score -= 0.05
        reasons.append("endpoint_missing=-0.05")
    if contains_any(record.claim, UNCERTAINTY_TERMS):
        score -= 0.06
        reasons.append("uncertain_language=-0.06")
    if contains_any(record.claim, OVERCLAIM_TERMS):
        score -= 0.18
        reasons.append("overclaim_language=-0.18")
    if record.limitations:
        score += 0.03
        reasons.append("limitations_declared=+0.03")
    score = max(0.0, min(1.0, score))
    return round(score, 4), reasons


def decision(score: float, record: EvidenceRecord) -> str:
    if score >= 0.75:
        return "evidence_anchor"
    if score >= 0.55:
        return "reviewable_support"
    if record.study_type in ["preclinical", "mechanism_study", "case_report", "case_series"]:
        return "hypothesis_or_context_only"
    return "weak_or_context_only"


def dikwp_record(record: EvidenceRecord, score: float, topic: str, domain: str) -> Dict[str, Any]:
    return {
        "record_id": record.record_id,
        "C": {
            "D": {
                "title": record.title,
                "year": record.year,
                "source_id": record.source_id,
                "sample_size": record.sample_size,
            },
            "I": {
                "cancer_topic": topic,
                "domain": domain,
                "biomarker": record.biomarker,
                "variant": record.variant,
                "intervention": record.intervention,
                "outcome": record.outcome,
            },
            "K": {
                "study_type": record.study_type,
                "claim": record.claim,
                "endpoint_types": record.endpoint_types,
            },
            "W": {
                "limitations": record.limitations,
                "medical_boundary": "research_evidence_only_no_clinical_recommendation",
            },
            "P": {
                "purpose": "support literature review, molecular tumor board preparation, or trial screening discussion under human expert review",
                "not_purpose": "diagnosis, treatment recommendation, or patient-specific decision automation",
            },
            "R": {
                "heuristic_evidence_score": score,
                "reliability": "borrowed_from_metadata_and_local_rules",
                "residual": "full-text appraisal, bias assessment, guideline currency, and clinician review required",
            },
        },
    }


def claim_card(record: EvidenceRecord, score: float, dec: str) -> Dict[str, Any]:
    kill = []
    if not record.source_id:
        kill.append("source identifier cannot be verified")
    if contains_any(record.claim, OVERCLAIM_TERMS):
        kill.append("claim uses unsupported certainty or cure language")
    if record.sample_size is None:
        kill.append("sample size absent")
    return {
        "record_id": record.record_id,
        "claim": record.claim or f"Evidence item about {record.cancer_type}",
        "support_scope": dec,
        "score": score,
        "residual": record.limitations + ["requires full-text and domain expert review"],
        "kill_conditions": kill or ["new contradictory higher-quality evidence", "wrong population or endpoint scope"],
    }


def semantic_closure(records: List[EvidenceRecord]) -> Dict[str, Any]:
    incomplete = []
    imprecise = []
    inconsistent = []
    for r in records:
        if r.sample_size is None or not r.source_id or not r.endpoint_types:
            incomplete.append(r.record_id)
        if contains_any(r.claim, UNCERTAINTY_TERMS):
            imprecise.append(r.record_id)
        if r.study_type in ["preclinical", "case_report"] and contains_any(r.claim, ["clinical", "standard", "practice-changing"]):
            inconsistent.append(r.record_id)
    total = max(1, len(records))
    stability = 1.0 - 0.35 * len(incomplete)/total - 0.20 * len(imprecise)/total - 0.30 * len(inconsistent)/total
    stability = max(0.0, min(1.0, stability))
    if stability >= 0.85:
        grade = "S4 Stable Closure"
    elif stability >= 0.70:
        grade = "S3 Supported Closure"
    elif stability >= 0.50:
        grade = "S2 Provisional Closure"
    elif stability >= 0.30:
        grade = "S1 Fragile Closure"
    else:
        grade = "S0 Blocked Closure"
    return {
        "three_no_profile": {
            "incomplete_records": incomplete,
            "imprecise_records": imprecise,
            "potentially_inconsistent_records": inconsistent,
        },
        "semantic_stability_score": round(stability, 4),
        "semantic_stability_grade": grade,
        "interpretation": "Stability reflects metadata completeness, uncertainty wording, and scope consistency. It is not a medical truth score.",
    }


def trial_queue(corpus: Corpus) -> List[Dict[str, Any]]:
    queue = []
    variant_terms = {v.gene.lower(): v for v in corpus.variants}
    for t in corpus.trials:
        text = " ".join([t.title, t.cancer_type, " ".join(t.biomarkers), " ".join(t.interventions), t.eligibility_notes]).lower()
        matched = [gene for gene in variant_terms if gene and gene in text]
        risk = 0.0
        notes = []
        if t.status.lower() not in ["recruiting", "not yet recruiting"]:
            risk += 0.25
            notes.append("trial_not_currently_recruiting")
        if not t.locations:
            risk += 0.2
            notes.append("location_missing")
        if not t.eligibility_notes:
            risk += 0.2
            notes.append("eligibility_notes_missing")
        queue.append({
            "trial_id": t.trial_id,
            "title": t.title,
            "cancer_type": t.cancer_type,
            "phase": t.phase,
            "status": t.status,
            "matched_biomarker_genes": matched,
            "decision": "research_coordinator_review_candidate" if matched and risk < 0.4 else "context_only_or_more_data_needed",
            "risk_notes": notes,
            "boundary": "Not patient-specific eligibility determination; requires ClinicalTrials.gov record, treating clinician, and research coordinator review.",
        })
    return queue


def molecular_signals(corpus: Corpus) -> List[Dict[str, Any]]:
    out = []
    refs = {r.record_id for r in corpus.records}
    for v in corpus.variants:
        evidence_count = len([e for e in v.evidence_refs if e in refs])
        if evidence_count >= 2:
            level = "research_review_priority"
        elif evidence_count == 1:
            level = "single_source_signal"
        else:
            level = "unanchored_signal"
        out.append({
            "gene": v.gene,
            "alteration": v.alteration,
            "cancer_type": v.cancer_type,
            "evidence_refs": ";".join(v.evidence_refs),
            "evidence_count_in_corpus": evidence_count,
            "signal_level": level,
            "signal_context": v.signal_context,
            "boundary": "Molecular signal for research/tumor-board preparation only; not a treatment recommendation.",
            "note": v.note,
        })
    return out


def research_gaps(corpus: Corpus, topic_counts: Counter) -> List[str]:
    gaps = []
    priority_topics = ["NSCLC", "Breast", "Colorectal", "HCC", "Pancreatic", "Hematologic", "Rare/Pediatric"]
    for t in priority_topics:
        if topic_counts.get(t, 0) == 0:
            gaps.append(f"Topic gap: {t} records absent or underrepresented in current corpus; add targeted searches.")
    endpoint_terms = Counter()
    for r in corpus.records:
        endpoint_terms.update([e.lower() for e in r.endpoint_types])
    for e in ["overall survival", "progression-free survival", "quality of life", "toxicity", "implementation", "cost-effectiveness"]:
        if endpoint_terms.get(e, 0) == 0:
            gaps.append(f"Endpoint gap: {e} evidence not represented.")
    if not corpus.trials:
        gaps.append("Trial gap: no clinical trial records connected; add ClinicalTrials.gov or registry export.")
    if not corpus.variants:
        gaps.append("Molecular gap: no variant signals connected; add molecular annotation exports if relevant.")
    return gaps[:12]


def analyze(path: str, outdir: str) -> Dict[str, Any]:
    corpus = load_corpus(path)
    out = Path(outdir)
    out.mkdir(parents=True, exist_ok=True)
    rows = []
    ledgers = []
    cards = []
    topic_counts = Counter()
    domain_counts = Counter()
    decision_counts = Counter()
    for r in corpus.records:
        topic, domain = classify_topic(r)
        score, reasons = evidence_score(r)
        dec = decision(score, r)
        topic_counts[topic] += 1
        domain_counts[domain] += 1
        decision_counts[dec] += 1
        rows.append({
            "record_id": r.record_id,
            "title": r.title,
            "year": r.year,
            "cancer_topic": topic,
            "domain": domain,
            "study_type": r.study_type,
            "sample_size": r.sample_size if r.sample_size is not None else "",
            "source_id": r.source_id,
            "evidence_score": score,
            "decision": dec,
            "score_reasons": ";".join(reasons),
        })
        ledgers.append(dikwp_record(r, score, topic, domain))
        cards.append(claim_card(r, score, dec))

    closure = semantic_closure(corpus.records)
    trials = trial_queue(corpus)
    variants = molecular_signals(corpus)
    gaps = research_gaps(corpus, topic_counts)

    report = {
        "system": "DIKWP OncoEvidence OS",
        "version": "0.1.0",
        "corpus_id": corpus.corpus_id,
        "title": corpus.title,
        "record_count": len(corpus.records),
        "trial_count": len(corpus.trials),
        "variant_signal_count": len(corpus.variants),
        "decision_summary": dict(decision_counts),
        "topic_counts": dict(topic_counts),
        "domain_counts": dict(domain_counts),
        "mean_evidence_score": round(sum(r["evidence_score"] for r in rows)/max(1,len(rows)), 4),
        "semantic_closure": closure,
        "top_research_gaps": gaps[:6],
        "action_boundary": "Research evidence organization, molecular tumor board preparation, and trial-screening discussion support only; no diagnosis, no treatment recommendation, no patient-specific decision automation.",
    }
    (out / "oncoevidence_report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    (out / "dikwp_oncology_ledger.json").write_text(json.dumps(ledgers, ensure_ascii=False, indent=2), encoding="utf-8")
    (out / "claim_cards.json").write_text(json.dumps(cards, ensure_ascii=False, indent=2), encoding="utf-8")
    (out / "semantic_closure_report.json").write_text(json.dumps(closure, ensure_ascii=False, indent=2), encoding="utf-8")
    (out / "molecular_signal_table.json").write_text(json.dumps(variants, ensure_ascii=False, indent=2), encoding="utf-8")
    (out / "trial_review_queue.json").write_text(json.dumps(trials, ensure_ascii=False, indent=2), encoding="utf-8")
    with (out / "evidence_matrix.csv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()) if rows else ["record_id"])
        writer.writeheader()
        writer.writerows(rows)
    with (out / "claim_cards.csv").open("w", newline="", encoding="utf-8") as f:
        fieldnames = ["record_id", "claim", "support_scope", "score", "residual", "kill_conditions"]
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for c in cards:
            writer.writerow({**c, "residual": ";".join(c["residual"]), "kill_conditions": ";".join(c["kill_conditions"])})
    if variants:
        with (out / "molecular_signal_table.csv").open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=list(variants[0].keys()))
            writer.writeheader()
            writer.writerows(variants)
    if trials:
        with (out / "trial_review_queue.csv").open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=list(trials[0].keys()))
            writer.writeheader()
            writer.writerows(trials)
    (out / "research_gap_report.md").write_text("# Research Gap Report\n\n" + "\n".join(f"- {g}" for g in gaps), encoding="utf-8")
    (out / "tumor_board_prep_note.md").write_text(make_tumor_board_note(corpus, rows, variants, trials, closure), encoding="utf-8")
    (out / "recommendations.md").write_text(make_recommendations(report), encoding="utf-8")
    return report


def make_tumor_board_note(corpus: Corpus, rows: List[Dict[str, Any]], variants: List[Dict[str, Any]], trials: List[Dict[str, Any]], closure: Dict[str, Any]) -> str:
    lines = ["# Tumor Board Preparation Note", "", "**Boundary:** This note is for research discussion preparation only. It is not medical advice, diagnosis, or treatment recommendation.", "", f"Corpus: {corpus.title}", f"Semantic stability: {closure['semantic_stability_grade']} ({closure['semantic_stability_score']})", "", "## Evidence Anchors"]
    for r in rows:
        if r["decision"] == "evidence_anchor":
            lines.append(f"- {r['record_id']}: {r['title']} ({r['study_type']}, score {r['evidence_score']})")
    lines.append("\n## Molecular Signals")
    for v in variants:
        lines.append(f"- {v['gene']} {v['alteration']} in {v['cancer_type']}: {v['signal_level']} ({v['boundary']})")
    lines.append("\n## Trial Review Candidates")
    for t in trials:
        if t["decision"] == "research_coordinator_review_candidate":
            lines.append(f"- {t['trial_id']}: {t['title']} ({t['status']}); matched biomarkers: {', '.join(t['matched_biomarker_genes'])}")
    lines.append("\n## Residuals")
    lines.append("- Full-text critical appraisal, local guidelines, patient-specific context, pathology confirmation, and clinical expert review are required before any clinical interpretation.")
    return "\n".join(lines)


def make_recommendations(report: Dict[str, Any]) -> str:
    return f"""# Recommendations

- Treat this corpus as **research organization material**, not as patient-specific guidance.
- Prioritize full-text review for records marked `evidence_anchor` and `reviewable_support`.
- Use `claim_cards.csv` to separate supported claims from hypothesis-only statements.
- Use `molecular_signal_table.csv` only for research or tumor-board preparation; do not infer treatment.
- Use `trial_review_queue.csv` only to prepare questions for a research coordinator.
- SemanticClosure grade: **{report['semantic_closure']['semantic_stability_grade']}**.

## Kill Conditions

- A record lacks source identity or uses overclaim/cure language.
- A preclinical mechanism claim is presented as clinical action.
- A trial queue is used as direct eligibility determination.
- The system is used for diagnosis, treatment selection, or patient-specific decision automation.

## Recovery

- Add verified identifiers and full-text appraisal.
- Add guideline currency and jurisdiction.
- Add clinician, pathologist, molecular tumor board, or research coordinator review.
- Downgrade unsupported clinical claims to research-only signals.
"""
