from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

@dataclass
class EvidenceRecord:
    record_id: str
    title: str
    year: int
    study_type: str
    cancer_type: str
    domain: str = ""
    biomarker: str = ""
    variant: str = ""
    intervention: str = ""
    outcome: str = ""
    sample_size: Optional[int] = None
    source_id: str = ""
    source_type: str = "literature"
    claim: str = ""
    limitations: List[str] = field(default_factory=list)
    endpoint_types: List[str] = field(default_factory=list)
    population: str = ""

@dataclass
class TrialRecord:
    trial_id: str
    title: str
    cancer_type: str
    phase: str
    status: str
    biomarkers: List[str] = field(default_factory=list)
    interventions: List[str] = field(default_factory=list)
    locations: List[str] = field(default_factory=list)
    eligibility_notes: str = ""

@dataclass
class VariantSignal:
    gene: str
    alteration: str
    cancer_type: str
    evidence_refs: List[str] = field(default_factory=list)
    signal_context: str = "research"
    note: str = ""

@dataclass
class Corpus:
    corpus_id: str
    title: str
    purpose: str
    constraints: List[str]
    records: List[EvidenceRecord]
    trials: List[TrialRecord] = field(default_factory=list)
    variants: List[VariantSignal] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
