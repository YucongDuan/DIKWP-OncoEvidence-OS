# Open Source Launch Plan

1. Publish the offline core on GitHub.
2. Provide synthetic demo corpus only.
3. Add connectors later for PubMed, ClinicalTrials.gov, Europe PMC, and local knowledge bases after privacy/security review.
4. Preserve NOTICE and CITATION metadata.
5. Offer official DIKWP OncoEvidence Review and training as value layers.
