# Medical Research Boundary

This system is for research evidence organization only. It must not be used to diagnose, prescribe, select therapy, determine trial eligibility, or automate clinical decisions.

Every molecular signal must remain a research/tumor-board preparation object until independently reviewed by qualified clinicians, pathologists, molecular experts, and research coordinators.
