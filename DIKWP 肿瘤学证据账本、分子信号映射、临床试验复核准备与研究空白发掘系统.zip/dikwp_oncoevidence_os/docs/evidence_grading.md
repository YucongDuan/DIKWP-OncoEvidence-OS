# Evidence Grading

The current evidence score is heuristic. It considers study type, sample size, source identifier, endpoint declaration, uncertainty language, overclaim language, and limitations. It is not a formal GRADE assessment and should be treated as a triage layer.
