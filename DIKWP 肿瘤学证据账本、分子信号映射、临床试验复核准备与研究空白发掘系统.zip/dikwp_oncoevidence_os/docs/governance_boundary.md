# Governance Boundary

Do not use this system for diagnosis, treatment recommendation, drug prescription, triage, trial eligibility determination, or automated clinical actions. Preserve evidence, residuals, and expert review boundaries.
