# Architecture

DIKWP OncoEvidence OS has four layers:

1. **Corpus Intake**: oncology literature metadata, molecular signals, trial records.
2. **DIKWP Ledger**: D/I/K/W/P/R registration for each evidence object.
3. **SemanticClosure Engine**: incomplete, imprecise, inconsistent evidence profiling.
4. **Research Outputs**: evidence matrix, claim cards, trial review queue, research gaps, tumor board preparation note.

The core is offline-first and contains no live clinical integration.
