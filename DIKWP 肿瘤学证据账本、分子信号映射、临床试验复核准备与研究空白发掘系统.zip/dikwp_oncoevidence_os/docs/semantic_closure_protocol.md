# SemanticClosure Protocol

Oncology evidence often contains incomplete metadata, imprecise language, and inconsistent scope. SemanticClosure separates:

- primary anchors: study type, population, endpoint, source identifier;
- local noise: vague words, missing fields, early-stage signals;
- residuals: full-text appraisal, bias, guideline currency, patient-specific context;
- kill conditions: overclaim, wrong population, wrong endpoint, unsupported clinical leap.
