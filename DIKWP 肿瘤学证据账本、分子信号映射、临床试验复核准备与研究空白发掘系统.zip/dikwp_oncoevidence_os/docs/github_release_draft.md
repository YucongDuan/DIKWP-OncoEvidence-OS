# GitHub Release Draft

## DIKWP OncoEvidence OS v0.1.0

Initial open-source release of the DIKWP oncology evidence ledger and SemanticClosure workbench. Includes synthetic demo corpus, evidence matrix generation, claim cards, molecular signal table, trial review queue, research gap report, and tumor board preparation note.

Medical boundary: research organization only; not clinical decision support.
