# Roadmap

- v0.2: PubMed export importer
- v0.3: ClinicalTrials.gov JSON importer
- v0.4: PRISMA screening mode
- v0.5: Molecular tumor board preparation template
- v1.0: DIKWP OncoEvidence Review Pack with TrustPassport integration
