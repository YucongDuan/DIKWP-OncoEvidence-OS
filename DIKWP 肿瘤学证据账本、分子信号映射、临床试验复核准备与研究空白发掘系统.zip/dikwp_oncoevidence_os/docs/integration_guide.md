# Integration Guide

Future connectors can be added for:

- PubMed / Entrez metadata;
- ClinicalTrials.gov v2 API exports;
- Europe PMC full-text metadata;
- local hospital literature libraries;
- molecular annotation tables;
- institutional review workflows.

All connectors should pass privacy, security, and medical research boundary review.
