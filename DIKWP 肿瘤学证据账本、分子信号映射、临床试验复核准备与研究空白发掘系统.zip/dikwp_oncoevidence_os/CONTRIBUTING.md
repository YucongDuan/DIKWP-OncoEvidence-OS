# Contributing

Contributions should preserve the medical research boundary. Do not add clinical decision automation, prescription logic, patient-facing treatment advice, or hidden network/telemetry behavior.
