# Research Gap Report

- Topic gap: HCC records absent or underrepresented in current corpus; add targeted searches.
- Topic gap: Pancreatic records absent or underrepresented in current corpus; add targeted searches.
- Topic gap: Hematologic records absent or underrepresented in current corpus; add targeted searches.
- Topic gap: Rare/Pediatric records absent or underrepresented in current corpus; add targeted searches.
- Endpoint gap: cost-effectiveness evidence not represented.