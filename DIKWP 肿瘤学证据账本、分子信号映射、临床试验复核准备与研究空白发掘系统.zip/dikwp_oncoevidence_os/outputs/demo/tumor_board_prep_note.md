# Tumor Board Preparation Note

**Boundary:** This note is for research discussion preparation only. It is not medical advice, diagnosis, or treatment recommendation.

Corpus: Synthetic Precision Oncology Evidence Demo Corpus
Semantic stability: S3 Supported Closure (0.775)

## Evidence Anchors
- R1: Phase III evidence map for targeted therapy in EGFR-mutant NSCLC (phase_iii_trial, score 0.9)
- R3: Systematic review of MSI-H colorectal cancer immunotherapy evidence (systematic_review, score 1.0)
- R6: Guideline-style early detection evidence map for lung cancer screening (guideline, score 1.0)

## Molecular Signals
- EGFR exon 19 deletion / L858R in NSCLC: single_source_signal (Molecular signal for research/tumor-board preparation only; not a treatment recommendation.)
- HER2 amplification in Breast: single_source_signal (Molecular signal for research/tumor-board preparation only; not a treatment recommendation.)
- MSI-H dMMR phenotype in Colorectal: single_source_signal (Molecular signal for research/tumor-board preparation only; not a treatment recommendation.)
- KRAS G12D in Pancreatic: single_source_signal (Molecular signal for research/tumor-board preparation only; not a treatment recommendation.)

## Trial Review Candidates
- NCT-SYNTH-001: Biomarker-selected NSCLC targeted therapy study (Recruiting); matched biomarkers: egfr
- NCT-SYNTH-002: KRAS G12D pancreatic cancer early phase combination study (Recruiting); matched biomarkers: kras

## Residuals
- Full-text critical appraisal, local guidelines, patient-specific context, pathology confirmation, and clinical expert review are required before any clinical interpretation.