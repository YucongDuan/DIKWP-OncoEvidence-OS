# Recommendations

- Treat this corpus as **research organization material**, not as patient-specific guidance.
- Prioritize full-text review for records marked `evidence_anchor` and `reviewable_support`.
- Use `claim_cards.csv` to separate supported claims from hypothesis-only statements.
- Use `molecular_signal_table.csv` only for research or tumor-board preparation; do not infer treatment.
- Use `trial_review_queue.csv` only to prepare questions for a research coordinator.
- SemanticClosure grade: **S3 Supported Closure**.

## Kill Conditions

- A record lacks source identity or uses overclaim/cure language.
- A preclinical mechanism claim is presented as clinical action.
- A trial queue is used as direct eligibility determination.
- The system is used for diagnosis, treatment selection, or patient-specific decision automation.

## Recovery

- Add verified identifiers and full-text appraisal.
- Add guideline currency and jurisdiction.
- Add clinician, pathologist, molecular tumor board, or research coordinator review.
- Downgrade unsupported clinical claims to research-only signals.
