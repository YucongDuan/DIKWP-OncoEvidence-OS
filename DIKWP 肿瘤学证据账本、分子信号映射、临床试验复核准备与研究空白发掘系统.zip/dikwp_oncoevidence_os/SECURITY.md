# Security Policy

The offline core should not contain network calls, credential capture, hidden telemetry, subprocess execution, browser automation, or clinical decision automation. Report issues through the repository issue tracker after removing sensitive data.
